sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("bookshop.managebooksandorders.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map